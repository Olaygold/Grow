import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-auth.js";
import { getDatabase, ref, get, update } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-database.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAELWzVQZiw2PxbNUT3-YK4a6KPHfYkdZ4",
  authDomain: "work-98965.firebaseapp.com",
  databaseURL: "https://work-98965-default-rtdb.firebaseio.com",
  projectId: "work-98965",
  storageBucket: "work-98965.appspot.com",
  messagingSenderId: "755408416828",
  appId: "1:755408416828:web:59f72561f27fb9ffa01339"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth();
const db = getDatabase();

// Function to fetch all withdrawal requests
function fetchWithdrawals() {
  const withdrawalRef = ref(db, 'withdrawals/');
  
  get(withdrawalRef)
    .then(snapshot => {
      if (snapshot.exists()) {
        const withdrawals = snapshot.val();
        populateWithdrawalTable(withdrawals);  // Populate the table with withdrawal data
      } else {
        alert("No withdrawal requests found.");
      }
    })
    .catch(error => {
      console.error("Error fetching withdrawals:", error);
      alert("Failed to fetch withdrawal requests. Please check the console.");
    });
}

// Function to populate the withdrawal table
function populateWithdrawalTable(withdrawals) {
  const tableBody = document.getElementById('withdrawal-table-body');
  if (!tableBody) {
    console.error("Table body element not found!");
    return;
  }
  
  tableBody.innerHTML = ''; // Clear existing rows

  for (const key in withdrawals) {
    const withdrawal = withdrawals[key];
    const row = document.createElement('tr');
    
    row.innerHTML = `
      <td>${withdrawal.accountName}</td>
      <td>${withdrawal.bankName}</td>
      <td>${withdrawal.accountNumber}</td>
      <td>${withdrawal.withdrawalAmount}</td>
      <td>${withdrawal.status}</td>
      <td>${new Date(withdrawal.timestamp).toLocaleString()}</td>
      <td><button onclick="markAsPaid('${key}')">Mark as Paid</button></td>
    `;

    tableBody.appendChild(row);
  }
}

// Function to mark a withdrawal as paid
function markAsPaid(withdrawalId) {
  const withdrawalRef = ref(db, 'withdrawals/' + withdrawalId);

  update(withdrawalRef, {
    status: 'Paid'  // Change the status to 'Paid'
  })
  .then(() => {
    alert("Withdrawal marked as paid.");
    fetchWithdrawals();  // Reload the list of withdrawals to reflect the change
  })
  .catch(error => {
    console.error("Error updating withdrawal status:", error);
    alert("Failed to mark withdrawal as paid. Please try again.");
  });
}

// Ensure the DOM is fully loaded before calling the fetchWithdrawals function
document.addEventListener('DOMContentLoaded', fetchWithdrawals);

// Expose the markAsPaid function globally so HTML elements can access it
window.markAsPaid = markAsPaid;