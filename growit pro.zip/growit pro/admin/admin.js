import { initializeApp } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-app.js";
import { getDatabase, ref, get, update } from "https://www.gstatic.com/firebasejs/11.0.2/firebase-database.js";

// Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAELWzVQZiw2PxbNUT3-YK4a6KPHfYkdZ4",
  authDomain: "work-98965.firebaseapp.com",
  databaseURL: "https://work-98965-default-rtdb.firebaseio.com",
  projectId: "work-98965",
  storageBucket: "work-98965.appspot.com",
  messagingSenderId: "755408416828",
  appId: "1:755408416828:web:59f72561f27fb9ffa01339"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getDatabase();

// Fetch all withdrawals from the database
function fetchWithdrawals() {
  const withdrawalRef = ref(db, 'withdrawals/');
  
  get(withdrawalRef).then(snapshot => {
    const withdrawals = snapshot.val();
    if (withdrawals) {
      populateWithdrawalTable(withdrawals);
    } else {
      alert("No withdrawal requests found.");
    }
  }).catch(error => {
    console.error("Error fetching withdrawals:", error);
    alert("Failed to fetch withdrawal requests.");
  });
}

// Populate the table with withdrawal data
function populateWithdrawalTable(withdrawals) {
  const withdrawalList = document.getElementById("withdrawal-list");
  withdrawalList.innerHTML = "";  // Clear previous data

  for (const withdrawalId in withdrawals) {
    const withdrawal = withdrawals[withdrawalId];
    
    const row = document.createElement("tr");
    
    // Create table data cells
    const userNameCell = document.createElement("td");
    userNameCell.textContent = withdrawal.userName;
    const accountNameCell = document.createElement("td");
    accountNameCell.textContent = withdrawal.accountName;
    const bankNameCell = document.createElement("td");
    bankNameCell.textContent = withdrawal.bankName;
    const amountCell = document.createElement("td");
    amountCell.textContent = withdrawal.withdrawalAmount;
    const statusCell = document.createElement("td");
    statusCell.textContent = withdrawal.status;
    const actionCell = document.createElement("td");
    
    // Create button for action
    if (withdrawal.status === "Processing") {
      const paidButton = document.createElement("button");
      paidButton.textContent = "Mark as Paid";
      paidButton.onclick = function() {
        markAsPaid(withdrawalId, withdrawal.userId, withdrawal.withdrawalAmount);
      };
      actionCell.appendChild(paidButton);
    }
    
    row.appendChild(userNameCell);
    row.appendChild(accountNameCell);
    row.appendChild(bankNameCell);
    row.appendChild(amountCell);
    row.appendChild(statusCell);
    row.appendChild(actionCell);
    
    withdrawalList.appendChild(row);
  }
}

// Function to mark a withdrawal as paid
function markAsPaid(withdrawalId, userId, withdrawalAmount) {
  const withdrawalRef = ref(db, 'withdrawals/' + withdrawalId);
  const userRef = ref(db, 'users/' + userId);

  // Update withdrawal status to "Paid"
  update(withdrawalRef, {
    status: "Paid"
  }).then(() => {
    // Subtract the withdrawal amount from the user's balance
    get(userRef).then(snapshot => {
      const user = snapshot.val();
      const currentBalance = user.balance;

      // Update user balance
      update(userRef, {
        balance: currentBalance - withdrawalAmount
      }).then(() => {
        alert("Withdrawal marked as Paid and balance updated.");
        fetchWithdrawals();  // Reload the withdrawal table
      }).catch(error => {
        console.error("Error updating user balance:", error);
        alert("Failed to update user balance.");
      });
    }).catch(error => {
      console.error("Error fetching user data:", error);
      alert("Failed to fetch user data.");
    });
  }).catch(error => {
    console.error("Error marking withdrawal as paid:", error);
    alert("Failed to mark withdrawal as paid.");
  });
}

// Fetch withdrawals on page load
window.onload = function() {
  fetchWithdrawals();
};