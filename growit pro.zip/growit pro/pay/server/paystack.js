import axios from 'axios';

const secretKey = "sk_live_ef2ab96dc1a3c0d667d4f586109e2ee19d317ab3";

async function verifyTransaction(reference) {
  const response = await axios.get(`https://api.paystack.co/transaction/verify/${reference}`, {
    headers: { Authorization: `Bearer ${secretKey}` }
  });
  return response.data;
}

export default { verifyTransaction };