import express from "express";
import bodyParser from "body-parser";
import crypto from "crypto";
import admin from "firebase-admin";

// Firebase Admin SDK Initialization
admin.initializeApp({
  credential: admin.credential.applicationDefault(),
  databaseURL: "https://your-database-url.firebaseio.com",
});

const app = express();
app.use(bodyParser.json());

// Firebase Database Reference
const db = admin.database();

// Paystack Secret Key
const PAYSTACK_SECRET = "sk_live_ef2ab96dc1a3c0d667d4f586109e2ee19d317ab3";

// Webhook Endpoint
app.post("/webhook", (req, res) => {
  // Verify the Paystack Webhook Signature
  const hash = crypto
    .createHmac("sha512", PAYSTACK_SECRET)
    .update(JSON.stringify(req.body))
    .digest("hex");

  if (hash === req.headers["x-paystack-signature"]) {
    const event = req.body;

    if (event.event === "charge.success") {
      const { email, amount } = event.data;
      const depositAmount = amount / 100; // Convert kobo to naira

      // Update Firebase Database with the new balance
      db.ref("users")
        .orderByChild("email")
        .equalTo(email)
        .once("value", (snapshot) => {
          if (snapshot.exists()) {
            snapshot.forEach((userSnapshot) => {
              const userKey = userSnapshot.key;
              const userData = userSnapshot.val();
              const newBalance = (userData.balance || 0) + depositAmount;

              db.ref("users/" + userKey)
                .update({ balance: newBalance })
                .then(() => {
                  console.log(`Deposit of ${depositAmount} added to ${email}`);
                })
                .catch((error) => {
                  console.error("Error updating user balance:", error);
                });
            });
          } else {
            console.error("User not found for email:", email);
          }
        });
    }

    res.status(200).send("Webhook received and processed successfully.");
  } else {
    res.status(400).send("Invalid Paystack signature.");
  }
});

// Start the Express Server
const PORT = 3000; // Change this if necessary
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});